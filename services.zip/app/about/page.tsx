export const runtime = "nodejs";

export default function AboutPage() {
  return (
    <main className="min-h-screen">
      <div className="mx-auto max-w-6xl px-4 py-10 space-y-6">
        <h1 className="text-3xl font-bold">О нас</h1>

        <div className="rounded-2xl border border-[#F9B44D] bg-[var(--background)] p-6 space-y-3">
          <p className="text-[#4B7488]">
            Мы продаём товары из каталога. Отправка — после подтверждения заказа.
          </p>
          <p className="text-[#4B7488]">
            Если укажете город и контакты — сюда же добавим «где находимся» и
            «как быстро отвечаем».
          </p>
        </div>
      </div>
    </main>
  );
}
