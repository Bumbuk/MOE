import ProductGrid from "../components/catalog/ProductGrid";
import CatalogControls from "../components/catalog/CatalogControls";
import { getSiteUrl } from "../lib/site-url";

export const dynamic = "force-dynamic";

type ApiResponse = {
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
  items: Array<{
    id: string;
    title: string;
    slug: string;
    category: string | null;
    priceFrom: number;
    thumb: { url: string; alt: string } | null;
    sizes: string[];
    colors: string[];
  }>;
};

function qs(params: Record<string, string | undefined>) {
  const sp = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v && v.trim()) sp.set(k, v);
  }
  return sp.toString();
}

async function getProducts(search: Record<string, string | undefined>) {
  const query = qs({
    q: search.q,
    category: search.category,
    sizes: search.sizes ?? search.size,
    minPrice: search.minPrice,
    maxPrice: search.maxPrice,
    sort: search.sort,
    page: search.page ?? "1",
    limit: search.limit ?? "24",
  });

  const url = new URL(`/api/products?${query}`, getSiteUrl());
  const res = await fetch(url.toString(), { cache: "no-store" });
  if (!res.ok) throw new Error("Не удалось загрузить товары");
  return (await res.json()) as ApiResponse;
}

function buildHref(sp: Record<string, string | undefined>, page: number) {
  const next = new URLSearchParams();
  for (const [k, v] of Object.entries(sp)) {
    if (v && v.trim()) next.set(k, v);
  }
  next.set("page", String(page));
  return `/?${next.toString()}`;
}

export default async function Page({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const sp = await searchParams;
  const data = await getProducts(sp);

  // Получаем номер страницы из query‑параметра. API возвращает только items,
  // поэтому вычисляем навигацию сами. Если результатов больше pageSize,
  // считаем, что есть следующая страница.
  const pageNum = Number(sp.page ?? "1");
  const pageSize = Number(sp.pageSize ?? sp.limit ?? "24");
  const prev = pageNum > 1 ? pageNum - 1 : null;
  const next = data.items.length === pageSize ? pageNum + 1 : null;
  const showPager = data.items.length > 20 || prev !== null || next !== null;

  return (
    <main className="min-h-screen">
      <div className="mx-auto max-w-6xl px-4 py-8 space-y-6">
        <header className="space-y-1">
          <h1 className="text-2xl font-bold tracking-tight">Каталог</h1>
          <div className="text-sm text-[#4B7488]">Найдено: {data.total}</div>
        </header>

        <CatalogControls />

        <ProductGrid items={data.items} />

        {/* Пагинация. Показываем, только если товаров больше 20 или есть предыдущая/следующая страница. */}
        {showPager ? (
          <div className="flex items-center justify-between pt-2">
            <div className="text-sm text-[#4B7488]">Страница {pageNum}</div>

            <div className="flex gap-2">
              <a
                href={prev ? buildHref(sp, prev) : "#"}
                className={
                  "rounded-xl border px-3 py-2 text-sm " +
                  (prev
                    ? "border-[#F9B44D] bg-[var(--background)] text-[#4B7488] hover:border-[#EC99A6]"
                    : "border-[#EADDCB] bg-[#FDE9D4] text-[#AAA19C] cursor-not-allowed")
                }
              >
                Назад
              </a>

              <a
                href={next ? buildHref(sp, next) : "#"}
                className={
                  "rounded-xl border px-3 py-2 text-sm " +
                  (next
                    ? "border-[#F9B44D] bg-[var(--background)] text-[#4B7488] hover:border-[#EC99A6]"
                    : "border-[#EADDCB] bg-[#FDE9D4] text-[#AAA19C] cursor-not-allowed")
                }
              >
                Вперёд
              </a>
            </div>
          </div>
        ) : null}
      </div>
    </main>
  );
}
