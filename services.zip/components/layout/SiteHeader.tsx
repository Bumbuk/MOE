import Link from "next/link";
import Container from "./Container";
import CartLink from "./CartLink";

export default function SiteHeader() {
  return (
    <header
      className="sticky top-0 z-50 border-b border-[#F9B44D] bg-[var(--background)]/90 backdrop-blur"
    >
      <Container className="py-4">
        <div className="flex items-center gap-4">
          <Link
            href="/"
            className="text-lg font-bold tracking-tight text-[#FF6634] hover:text-[#EC99A6]"
          >
            Магазин
          </Link>

          <nav className="hidden md:flex items-center gap-4 text-sm text-[#4B7488]">
            <Link className="hover:text-[#FF6634]" href="/about">
              О нас
            </Link>
            <Link className="hover:text-[#FF6634]" href="/delivery">
              Доставка
            </Link>
            <Link className="hover:text-[#FF6634]" href="/contacts">
              Контакты
            </Link>
          </nav>

          <div className="ml-auto flex items-center gap-3">
            {/* Поиск убран по просьбе пользователя. Оставляем только ссылку на корзину. */}
            <CartLink />
          </div>
        </div>
      </Container>
    </header>
  );
}
